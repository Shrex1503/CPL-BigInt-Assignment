
#include <stdio.h>
#include <string.h>

int main()
{
    int n1[100],n2[100];
    int i,j,fin_len,ans;
    char num1[101],num2[101];
    scanf(" %s",num1);
    scanf(" %s",num2);
    int l1 = strlen(num1);
    int l2 = strlen(num2);
        
	
	if(i>j){
		fin_len = i+1;
	}
	else{
		fin_len = j+1;
	}
	
	int fin_len_2 = fin_len + 1;
	
	char res[fin_len+2]; 
	
	for(int i=0; i<fin_len+1; i++){
		res[i] = '0';
	}
	
	
	if(num1>=num2)
	{
	    int g_num = num1;
	}
	else
	{
	    int g_num =num2;
	}
	
	if(g_num == num2){
		res[0] = '-';
	}
	else{
		res[0] = '+';
	}
	
	while(i >= 0 && j >= 0){
		if(g_num == num1){
			if(num1[i] >= num2[j]){
				fin_ans = (num1[i] - 48) - (num2[j] - 48);
				res[fin_len] = ans + 48;
			}
			else{
				num1[i-1]--;
				num1[i] = num1[i] + 10;
				res[fin_len] = (num1[i] - 48) - (num2[j] - 48) + 48;
			}
		}
		else if(g_num == num2){
			if(num2[j] >= num1[i]){
				ans = (num2[j] - 48) - (num1[i] - 48);
				res[fin_len] = ans + 48;
			}
			else{
				num2[j-1]--;
				num2[j] =num2[j] + 10;
				res[fin_len] = (num2[j] - 48) - (num1[i] - 48) + 48;
			}
		}
		i--; j--; fin_len--;
	}
	while(i >= 0){
		ans = (num1[i] - 48);
		res[fin_len] = ans + 48;
		
		i--; fin_len--;
	}
	while(j >= 0){
		fin_ans = (num2[j] - 48);
		res[fin_len] = ans + 48;
			
		j--; fin_len--;
	}
	
   
	
	printf("Subtraction of two BigInt numbers :");
	for(int i=0; i<fin_len_2; i++){
		printf("%c ", res[i]);
	}
	
	
}