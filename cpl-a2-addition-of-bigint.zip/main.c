/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>
#include <string.h>

int main()
{
    int n1[100],n2[100];
    int ans[101]={0};
    int i,j,tmp,max,min;
    char num1[101],num2[101];
    scanf(" %s",num1);
    scanf(" %s",num2);
    int l1 = strlen(num1);
    int l2 = strlen(num2);
    for(i=0; i<l1;i++)
    {
        n1[i] = int (num1[l1-1-i]) - 48;
        
    }
    
    for(i=0; i<l2;i++)
    {
        n2[i] = int (num2[l2-1-i]) - 48;
        
    }
    
    if(l1>=l2)
    {
        max = l1;
        min = l2;
        
    }
    else
    {
        max = l2;
        min = l1;
        
    }
    
    int carry = 0;
    int sum[max + 1]={0};
    
    for(k = 0; k< max; k++)
    {
        sum[k] = (n1[k] + n2[k] + carry)%10;
        
        if((n1[k] + n2[k] + carry) >=10)
        {carry = 1};
         
        else
        {carry =0;}
        
    }
    
    sum[max] = carry;
    
    for(j = max; j>=0; j--)
    {
        printf("%d"; sum[j]);
    }